# DOOM via Checkboxes — iPhone touch version

Based on Andrew Healey's `healeycodes/doom-checkboxes` project.

## Run

Upload this folder to an HTTPS static host such as GitHub Pages, then open the page in iPhone Safari. The page loads the original `doom.js` and `doom.wasm` from Andrew Healey's public repository and Checkboxland from unpkg.

## Controls

- START: Enter
- ◀ / ▶: turn
- ▲ / ▼: forward / backward
- STRAFE + direction: strafe
- FIRE: Ctrl
- USE / OPEN: Space

Controls are hold-to-press and use Pointer Events for iPhone Safari.
