import { Checkboxland } from "https://unpkg.com/checkboxland?module";
window.Checkboxland = Checkboxland;
const canvas=document.querySelector("#screen"), loading=document.querySelector("#loading");
const cbl=new Checkboxland({dimensions:"160x100",selector:"#checkboxes"});
window.cbl=cbl;cbl.print("DOOM WebAssembly loading..");
canvas.getContext("2d");
const video=document.querySelector("#doom-video");
video.srcObject=canvas.captureStream();
let started=false;
const start=()=>{if(started||window.doomLoaded!==true)return;started=true;loading.style.display="none";cbl.renderVideo(document.querySelector("#doom-video"),{threshold:20});};
document.addEventListener("touchstart",()=>start(),{passive:true});
document.addEventListener("pointerdown",()=>start(),{passive:true});
const buttons=[
["enterButton",13],["leftButton",0xac],["rightButton",0xae],["upButton",0xad],["downButton",0xaf],["ctrlButton",0x80+0x1d],["spaceButton",32],["altButton",0x80+0x38]
];
function bind(id,key){const b=document.getElementById(id);let down=false;const press=e=>{e.preventDefault();if(down)return;down=true;b.classList.add("pressed");if(window.doomLoaded)window.dispatchEvent(new CustomEvent("doom-touch",{detail:{type:"down",key}}));};const release=e=>{e.preventDefault();if(!down)return;down=false;b.classList.remove("pressed");if(window.doomLoaded)window.dispatchEvent(new CustomEvent("doom-touch",{detail:{type:"up",key}}));};b.addEventListener("pointerdown",press);b.addEventListener("pointerup",release);b.addEventListener("pointercancel",release);b.addEventListener("pointerleave",e=>{if(e.pointerType!=="mouse")release(e)});}
buttons.forEach(x=>bind(...x));
window.addEventListener("doom-touch",e=>{const key=e.detail.key;const type=e.detail.type;const ev=new KeyboardEvent(type==="down"?"keydown":"keyup",{keyCode:key,which:key,bubbles:true});canvas.dispatchEvent(ev)});
